﻿#include<iostream>
#include<fstream>
#include<string>
#include<conio.h>
#include<Windows.h>
using namespace std;

struct SinhVien{
	string MaSV;
	string TenSV;
	double DiemTB;
};

struct NODE{
	SinhVien Data;
	struct NODE *Next;
};

struct LIST{
	NODE *Head, *Tail;
};

void InitList(LIST &l);
void InputList(LIST &l);
void OutputList(LIST l);
void SaveListToFile(LIST l);
void ReadListFromFile(LIST l);
void OutputListByCode(LIST l);
void OutputListByName(LIST l);
void Menu(int &h, LIST &l);

void main()
{
	LIST l;
	int h = 0;
	InitList(l);
	Menu(h, l);
	_getch();
}

void InitList(LIST &l)
{
	l.Head = l.Tail = NULL;
}

NODE* CreateNode(SinhVien sv)
{
	NODE *p = new NODE;
	if (p == NULL)
		return NULL;
	p->Data = sv;
	p->Next = NULL;
	return p;
}

void AddTail(LIST &l, NODE *p)
{
	if (l.Head == NULL)
		l.Head = l.Tail = p;
	else{
		l.Tail->Next = p;
		l.Tail = p;
	}
}

// Hàm nhập danh sách sinh viên
void InputList(LIST &l){
	system("cls");
	cout << "====== Nhap danh sach sinh vien ======\n";
	int n, h;
	cout << "Nhap so luong sinh vien: ";
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		NODE *sv = new NODE;
		cout << "Nhap sinh vien thu " << i << endl;
		cout << "Ma sinh vien: ";
		fflush(stdin);
		getline(cin, sv->Data.MaSV);
		cout << "Ten sinh vien: ";
		getline(cin, sv->Data.TenSV);
		cout << "Diem trung binh: ";
		cin >> sv->Data.DiemTB;
		NODE *p = CreateNode(sv->Data);
		AddTail(l, p);
		cout << endl;
	}
	system("pause");
	Menu(h, l);
}

// Hàm xuất danh sách sinh viên
void OutputList(LIST l)
{
	int i = 0;
	cout << "====== Danh sach sinh vien ======" << endl;
	for (NODE*p = l.Head; p != NULL; p = p->Next)
	{
		i++;
		cout << "Sinh vien thu " << i << endl;
		cout << "Ma sinh vien: " << p->Data.MaSV << endl;
		cout << "Ten sinh vien: " << p->Data.TenSV << endl;
		cout << "Diem trung binh: " << p->Data.DiemTB << endl;
		cout << endl;
	}
}

// Lưu danh sách xuống file
void SaveListToFile(LIST l)
{
	system("cls");
	ofstream os;
	os.open("DanhSachSV.txt", ios::out);
	int h, i = 0;
	for (NODE*p = l.Head; p != NULL; p = p->Next)
	{
		i++;
		os << "Sinh vien thu " << i << endl;
		os << "Ma sinh vien: " << p->Data.MaSV << endl;
		os << "Ten sinh vien: " << p->Data.TenSV << endl;
		os << "Diem trung binh: " << p->Data.DiemTB << endl;
		os << endl;
	}
	os.close();
	cout << "Danh sach sinh vien da duoc luu vao file!" << endl;
	system("pause");
	Menu(h, l);
}

// Hàm đọc danh sách từ file
void ReadListFromFile(LIST l)
{
	system("cls");
	int h;
	cout << "====== Danh sach sinh vien doc tu file ======" << endl;
	ifstream is;
	is.open("DanhSachSV.txt", ios::in);
	while (!is.eof())
	{
		string data;
		fflush(stdin);
		getline(is, data);
		cout << data << endl;
	}
	is.close();
	system("pause");
	Menu(h, l);
}

// Hàm xuất danh sách theo mã sinh viên
void OutputListByCode(LIST l)
{
	system("cls");
	int h = 0, i = 0;
	cout << "====== Danh sach sinh vien theo ma ======" << endl;
	for (NODE*p = l.Head; p != NULL; p = p->Next)
	{
		i++;
		cout << "Sinh vien thu " << i << endl;
		cout << "Ma sinh vien: " << p->Data.MaSV << endl;
		cout << endl;
	}
	system("pause");
	Menu(h, l);
}

// Hàm xuất danh sách theo tên sinh viên
void OutputListByName(LIST l)
{
	system("cls");
	int h = 0, i = 0;
	cout << "====== Danh sach sinh vien theo ten ======" << endl;
	for (NODE*p = l.Head; p != NULL; p = p->Next)
	{
		i++;
		cout << "Sinh vien thu " << i << endl;
		cout << "Ten sinh vien: " << p->Data.TenSV << endl;
		cout << endl;
	}
	system("pause");
	Menu(h, l);
}

void Menu(int &h, LIST &l)
{
	system("cls");
	cout << "====== Quan ly danh sach sinh vien ======" << endl;
	cout << "1. Nhap danh sach sinh vien" << endl;
	cout << "2. Luu danh sach sinh vien vao file" << endl;
	cout << "3. Doc danh sach sinh vien tu file" << endl;
	cout << "4. Xuat danh sach sinh vien theo ma" << endl;
	cout << "5. Xuat danh sach sinh vien theo ten" << endl;
	cout << "6. Ket thuc" << endl;
	cout << "Ban chon: ";
	cin >> h;
	if (h == 1)
		InputList(l);
	if (h == 2)
		SaveListToFile(l);
	if (h == 3)
		ReadListFromFile(l);
	if (h == 4)
		OutputListByCode(l);
	if (h == 5)
		OutputListByName(l);
	if (h == 6)
		exit(0);
}